<template>
  <div>
    <h1>王哥北大前女友</h1>
  </div>
</template>

<script>
export default {
}

</script>
<style lang='less' scoped>

</style>

var userInfo = {
  data: {
    id: 9527,
    username: 'hwj',
    rid: 'R0001',
    mobile: 'hwj1234',
    email: '123@qq.com',
    token: 'Bearer'
  },
  meta: {
    msg: '登录成功',
    status: 200
  }
}

var user = {
  userInfo
}

export default user
